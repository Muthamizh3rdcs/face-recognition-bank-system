#!/bin/bash
# Bank of Muthamizh - Quick Setup Script
# Run this from the project root

echo "=========================================="
echo "  Bank of Muthamizh - Setup Script"
echo "  Progress for Prosperity"
echo "=========================================="

# 1. Setup Python virtual environment
cd backend
echo ""
echo "[1/4] Setting up Python environment..."
python3 -m venv venv
source venv/bin/activate

# 2. Install dependencies
echo ""
echo "[2/4] Installing dependencies..."
pip install flask flask-cors mysql-connector-python python-dotenv reportlab Pillow numpy

# Optional: Install face recognition (comment out if not needed)
# echo "Installing face recognition (this may take a while)..."
# pip install cmake dlib face-recognition opencv-python

# 3. Configure .env
echo ""
echo "[3/4] Configuring environment..."
if [ ! -f .env ]; then
  cp .env.example .env 2>/dev/null || echo "Please update .env with your MySQL credentials"
fi
echo "Please update backend/.env with your MySQL password!"

# 4. Setup database
echo ""
echo "[4/4] Setting up database..."
echo "Run this SQL command to create the database:"
echo "mysql -u root -p < ../database/schema.sql"
echo ""
echo "=========================================="
echo "SETUP COMPLETE!"
echo ""
echo "To START the backend:"
echo "  cd backend && source venv/bin/activate"
echo "  python app.py"
echo ""
echo "To VIEW the frontend:"
echo "  Open frontend/index.html in browser"
echo "  Or use: python3 -m http.server 8080 (in frontend folder)"
echo "  Then visit: http://localhost:8080"
echo "=========================================="
