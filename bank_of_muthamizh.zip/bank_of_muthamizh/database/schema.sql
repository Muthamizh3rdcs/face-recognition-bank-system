-- ==========================================
-- Bank of Muthamizh - Complete Database Schema
-- Progress for Prosperity
-- ==========================================

CREATE DATABASE IF NOT EXISTS bank_of_muthamizh CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bank_of_muthamizh;

-- Customers Table
CREATE TABLE IF NOT EXISTS customers (
    account_number VARCHAR(20) PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL,
    address TEXT,
    date_of_birth DATE,
    password_hash VARCHAR(255) NOT NULL,
    face_encoding_path VARCHAR(255),
    balance DECIMAL(15,2) DEFAULT 0.00,
    account_type VARCHAR(20) DEFAULT 'Savings',
    status VARCHAR(20) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_phone (phone),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Transactions Table
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    account_number VARCHAR(20) NOT NULL,
    transaction_type VARCHAR(20) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    balance_before DECIMAL(15,2) NOT NULL,
    balance_after DECIMAL(15,2) NOT NULL,
    description TEXT,
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified_by_face BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (account_number) REFERENCES customers(account_number) ON DELETE CASCADE,
    INDEX idx_account (account_number),
    INDEX idx_date (transaction_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Loan Applications Table
CREATE TABLE IF NOT EXISTS loan_applications (
    loan_id INT AUTO_INCREMENT PRIMARY KEY,
    account_number VARCHAR(20) NOT NULL,
    loan_type VARCHAR(50) NOT NULL COMMENT 'Home/Personal/Education/Vehicle/Business/Gold',
    loan_amount DECIMAL(15,2) NOT NULL,
    tenure_months INT NOT NULL,
    monthly_income DECIMAL(15,2) NOT NULL,
    pancard_number VARCHAR(10) NOT NULL,
    aadhar_number VARCHAR(12) NOT NULL,
    pancard_image_path VARCHAR(255),
    aadhar_image_path VARCHAR(255),
    employment_type VARCHAR(50),
    purpose TEXT,
    interest_rate DECIMAL(5,2) DEFAULT 10.50,
    emi_amount DECIMAL(15,2),
    status VARCHAR(20) DEFAULT 'Pending' COMMENT 'Pending/Approved/Rejected/Disbursed',
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reviewed_at TIMESTAMP NULL,
    FOREIGN KEY (account_number) REFERENCES customers(account_number) ON DELETE CASCADE,
    INDEX idx_account (account_number),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Login Attempts Table
CREATE TABLE IF NOT EXISTS login_attempts (
    attempt_id INT AUTO_INCREMENT PRIMARY KEY,
    account_number VARCHAR(20) NOT NULL,
    attempt_type VARCHAR(20) NOT NULL,
    ip_address VARCHAR(45),
    attempt_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_account (account_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SELECT 'Bank of Muthamizh Database Ready!' as Status;
SHOW TABLES;
