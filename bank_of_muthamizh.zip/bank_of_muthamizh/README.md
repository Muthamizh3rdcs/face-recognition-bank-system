# 🏦 Bank of Muthamizh - Complete Banking Application
**Progress for Prosperity | முன்னேற்றம் மட்டுமே இலக்கு**

---

## 📋 Features

| Feature | Description |
|---------|-------------|
| ✅ **Account Register** | Multi-step registration with face capture |
| ✅ **Secure Login** | Account number + password + optional face verification |
| ✅ **Home Dashboard** | Balance, stats, quick actions |
| ✅ **User Profile** | Full profile details with avatar |
| ✅ **Account Details** | Account info + statistics |
| ✅ **Deposit** | Deposit with receipt + PDF download |
| ✅ **Withdrawal** | Withdraw with receipt + PDF download |
| ✅ **Loans** | 6 loan types with EMI calculator + KYC verification |
| ✅ **KYC / Verification** | PAN card + Aadhar card + monthly income |
| ✅ **Account PDF** | Download complete account statement as PDF |
| ✅ **Transaction Receipts** | PDF receipt for every transaction |
| ✅ **Face Recognition** | Optional biometric authentication |

---

## 🏗️ Tech Stack

```
Frontend:  HTML5, CSS3 (Custom), Vanilla JavaScript
Backend:   Python (Flask) + REST API
Database:  MySQL
PDF:       ReportLab (Python)
Auth:      Session-based + SHA-256 password + Face Recognition (optional)
```

---

## 📁 Project Structure

```
bank_of_muthamizh/
├── frontend/
│   ├── index.html          ← Login + Register (multi-step)
│   ├── pages/
│   │   └── dashboard.html  ← Complete dashboard (all features)
│   ├── css/
│   │   └── style.css       ← Full stylesheet
│   └── images/
├── backend/
│   ├── app.py              ← Flask API (all endpoints)
│   ├── requirements.txt
│   └── .env                ← Configure DB credentials here
├── database/
│   └── schema.sql          ← MySQL schema + tables
└── setup.sh                ← Auto-setup script
```

---

## ⚡ Quick Start

### Step 1: Database Setup

```bash
# Login to MySQL
mysql -u root -p

# Run schema
source database/schema.sql
```

### Step 2: Backend Setup

```bash
cd backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install packages
pip install flask flask-cors mysql-connector-python python-dotenv reportlab Pillow numpy

# Configure .env
nano .env
```

**.env file:**
```
SECRET_KEY=your-secret-key-here
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=YOUR_MYSQL_PASSWORD
DB_NAME=bank_of_muthamizh
PORT=5000
```

### Step 3: Start Backend

```bash
cd backend
source venv/bin/activate
python app.py
```
Backend runs at: `http://localhost:5000`

### Step 4: Open Frontend

```bash
# Option 1: Open directly in browser
open frontend/index.html

# Option 2: Local server (recommended)
cd frontend
python3 -m http.server 8080
# Visit: http://localhost:8080
```

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/register` | Create new account |
| POST | `/api/login` | Login with credentials |
| GET | `/api/account` | Get account details |
| GET | `/api/transactions` | Get transaction history |
| POST | `/api/deposit` | Deposit money |
| POST | `/api/withdraw` | Withdraw money |
| GET | `/api/loans` | Get loan applications |
| POST | `/api/loans/apply` | Apply for loan |
| POST | `/api/loans/calculate` | Calculate EMI |
| POST | `/api/receipt/download` | Download receipt PDF |
| GET | `/api/account/download-pdf` | Download account statement PDF |
| POST | `/api/logout` | Logout |
| GET | `/api/health` | Health check |

---

## 🏦 Loan Types & Interest Rates

| Loan Type | Interest Rate | Max Tenure |
|-----------|--------------|------------|
| 🏠 Home Loan | 8.50% p.a. | 240 months |
| 👤 Personal Loan | 12.00% p.a. | 60 months |
| 🎓 Education Loan | 9.50% p.a. | 120 months |
| 🚗 Vehicle Loan | 10.50% p.a. | 84 months |
| 🏢 Business Loan | 14.00% p.a. | 84 months |
| 🥇 Gold Loan | 7.50% p.a. | 36 months |

---

## 📱 Face Recognition (Optional)

The app works without face recognition in **password-only mode**.
To enable face recognition:

```bash
# Install prerequisites (Ubuntu/Debian)
sudo apt-get install cmake build-essential

# Install face recognition
pip install dlib face-recognition opencv-python
```

Then restart the backend. It will auto-detect and enable face recognition.

---

## 📄 PDF Features

1. **Transaction Receipts** - Generated for each deposit/withdrawal with:
   - Receipt number, account details
   - Transaction amount and balance
   - Timestamp and bank info

2. **Account Statement PDF** - Complete account document with:
   - Profile information
   - Current balance
   - Last 20 transactions table
   - Professional formatting with Bank branding

---

## 🔒 Security Features

- SHA-256 password hashing
- Session-based authentication
- Optional face recognition (biometric)
- KYC verification for loans (PAN + Aadhar)
- Account status validation (Active/Inactive)

---

## 🚀 Production Notes

1. Change `SECRET_KEY` to a strong random value
2. Use HTTPS in production
3. Set `DEBUG=False` in `.env`
4. Use a proper WSGI server (gunicorn, uWSGI)
5. Configure CORS properly for your domain

---

*Bank of Muthamizh - Serving Tamil Nadu with Pride 🏦*
