"""
Bank of Muthamizh - Complete Backend Application
Progress for Prosperity
Features: Register, Login, Dashboard, Deposit, Withdrawal, Loans, PDF Generation
"""

from flask import Flask, request, jsonify, session, send_file
from flask_cors import CORS
import mysql.connector
from mysql.connector import Error
import hashlib
import numpy as np
import os
import base64
import io
import random
from datetime import datetime, date
import secrets
from dotenv import load_dotenv
import logging
import json

# PDF generation
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.pdfgen import canvas as pdf_canvas

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', secrets.token_hex(32))
CORS(app, supports_credentials=True, origins=["*"])

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DB_CONFIG = {
    'host': os.getenv('DB_HOST', 'localhost'),
    'port': int(os.getenv('DB_PORT', 3306)),
    'user': os.getenv('DB_USER', 'root'),
    'password': os.getenv('DB_PASSWORD', ''),
    'database': os.getenv('DB_NAME', 'bank_of_muthamizh'),
    'charset': 'utf8mb4',
    'collation': 'utf8mb4_unicode_ci'
}

UPLOAD_DIR = 'uploads'
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(os.path.join(UPLOAD_DIR, 'kyc'), exist_ok=True)

# ==========================================
# Face Recognition (Optional - Graceful Fallback)
# ==========================================
FACE_RECOGNITION_AVAILABLE = False
FACE_ENCODINGS_DIR = 'face_data'
os.makedirs(FACE_ENCODINGS_DIR, exist_ok=True)

try:
    import cv2
    import face_recognition
    FACE_RECOGNITION_AVAILABLE = True
    logger.info("Face recognition module loaded successfully")
except ImportError:
    logger.warning("Face recognition not available - using password-only auth")

# ==========================================
# Database Functions
# ==========================================

def get_db():
    try:
        return mysql.connector.connect(**DB_CONFIG)
    except Error as e:
        logger.error(f"DB connection error: {e}")
        return None

def query(sql, params=None, fetch=False, fetch_one=False):
    conn = get_db()
    if not conn:
        return None
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(sql, params or ())
        if fetch_one:
            result = cur.fetchone()
        elif fetch:
            result = cur.fetchall()
        else:
            conn.commit()
            result = cur.lastrowid
        cur.close()
        conn.close()
        return result
    except Error as e:
        logger.error(f"Query error: {e}")
        if conn:
            conn.close()
        return None

# ==========================================
# Helper Functions
# ==========================================

def hash_password(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

def gen_account():
    while True:
        acc = f"BOM{random.randint(1000000000, 9999999999)}"
        if not query("SELECT account_number FROM customers WHERE account_number=%s", (acc,), fetch_one=True):
            return acc

def serialize_dates(obj):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, (datetime, date)):
                obj[k] = v.isoformat()
            elif isinstance(v, (int, float)):
                pass
    return obj

def calc_emi(principal, rate_annual, months):
    r = rate_annual / (12 * 100)
    if r == 0:
        return principal / months
    emi = principal * r * (1 + r)**months / ((1 + r)**months - 1)
    return round(emi, 2)

# ==========================================
# Face Recognition Functions
# ==========================================

def save_face(account_number, image_b64):
    if not FACE_RECOGNITION_AVAILABLE:
        return True  # Skip face in fallback mode
    try:
        img_bytes = base64.b64decode(image_b64.split(',')[1] if ',' in image_b64 else image_b64)
        nparr = np.frombuffer(img_bytes, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        encodings = face_recognition.face_encodings(rgb)
        if encodings:
            path = os.path.join(FACE_ENCODINGS_DIR, f"{account_number}.npy")
            np.save(path, encodings[0])
            return path
        return None
    except Exception as e:
        logger.error(f"Face save error: {e}")
        return None

def verify_face(account_number, image_b64):
    if not FACE_RECOGNITION_AVAILABLE:
        return True  # Skip face in fallback mode
    try:
        path = os.path.join(FACE_ENCODINGS_DIR, f"{account_number}.npy")
        if not os.path.exists(path):
            return False
        stored = np.load(path)
        img_bytes = base64.b64decode(image_b64.split(',')[1] if ',' in image_b64 else image_b64)
        nparr = np.frombuffer(img_bytes, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        encodings = face_recognition.face_encodings(rgb)
        if encodings:
            return face_recognition.compare_faces([stored], encodings[0], tolerance=0.6)[0]
        return False
    except Exception as e:
        logger.error(f"Face verify error: {e}")
        return False

# ==========================================
# PDF Generation
# ==========================================

def generate_receipt_pdf(data, receipt_type):
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=2*cm, leftMargin=2*cm, topMargin=2*cm, bottomMargin=2*cm)
    styles = getSampleStyleSheet()
    elements = []

    title_style = ParagraphStyle('title', parent=styles['Title'], fontSize=20, textColor=colors.HexColor('#1a237e'), alignment=TA_CENTER, spaceAfter=5)
    sub_style = ParagraphStyle('sub', parent=styles['Normal'], fontSize=10, textColor=colors.HexColor('#5c6bc0'), alignment=TA_CENTER, spaceAfter=20)
    header_style = ParagraphStyle('header', parent=styles['Heading2'], fontSize=14, textColor=colors.HexColor('#1a237e'), spaceAfter=10)
    normal_style = ParagraphStyle('normal', parent=styles['Normal'], fontSize=10, spaceAfter=5)
    bold_style = ParagraphStyle('bold', parent=styles['Normal'], fontSize=11, fontName='Helvetica-Bold', spaceAfter=5)
    success_style = ParagraphStyle('success', parent=styles['Normal'], fontSize=14, textColor=colors.HexColor('#2e7d32'), alignment=TA_CENTER, fontName='Helvetica-Bold')

    elements.append(Paragraph("🏦 Bank of Muthamizh", title_style))
    elements.append(Paragraph("Progress for Prosperity | மதுரை, தமிழ்நாடு", sub_style))
    elements.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor('#1a237e')))
    elements.append(Spacer(1, 0.5*cm))

    elements.append(Paragraph(f"{receipt_type} Receipt", header_style))

    receipt_data = [
        ['Field', 'Details'],
    ]
    for k, v in data.items():
        receipt_data.append([k, str(v)])

    t = Table(receipt_data, colWidths=[7*cm, 11*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a237e')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 11),
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f5f5f5')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#e8eaf6')]),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 10),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#9fa8da')),
        ('PADDING', (0, 0), (-1, -1), 8),
    ]))
    elements.append(t)
    elements.append(Spacer(1, 1*cm))

    elements.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#9fa8da')))
    elements.append(Spacer(1, 0.3*cm))
    elements.append(Paragraph("✅ Transaction Successful", success_style))
    elements.append(Spacer(1, 0.3*cm))
    elements.append(Paragraph(f"Generated on: {datetime.now().strftime('%d %B %Y, %I:%M %p')}", 
                               ParagraphStyle('ts', parent=styles['Normal'], fontSize=9, textColor=colors.grey, alignment=TA_CENTER)))
    elements.append(Spacer(1, 0.3*cm))
    elements.append(Paragraph("Bank of Muthamizh | IFSC: BOMUT0000001 | Customer Care: 1800-XXX-XXXX", 
                               ParagraphStyle('footer', parent=styles['Normal'], fontSize=8, textColor=colors.grey, alignment=TA_CENTER)))

    doc.build(elements)
    buf.seek(0)
    return buf


def generate_account_pdf(account, transactions):
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=2*cm, leftMargin=2*cm, topMargin=2*cm, bottomMargin=2*cm)
    styles = getSampleStyleSheet()
    elements = []

    title_style = ParagraphStyle('title', parent=styles['Title'], fontSize=22, textColor=colors.HexColor('#1a237e'), alignment=TA_CENTER)
    sub_style = ParagraphStyle('sub', parent=styles['Normal'], fontSize=10, textColor=colors.HexColor('#5c6bc0'), alignment=TA_CENTER, spaceAfter=15)
    section_style = ParagraphStyle('section', parent=styles['Heading2'], fontSize=13, textColor=colors.HexColor('#1a237e'), spaceBefore=15, spaceAfter=8)

    elements.append(Paragraph("🏦 Bank of Muthamizh", title_style))
    elements.append(Paragraph("Progress for Prosperity | Account Statement", sub_style))
    elements.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor('#1a237e')))
    elements.append(Spacer(1, 0.5*cm))

    elements.append(Paragraph("Account Holder Details", section_style))
    
    # Profile table
    profile_data = [
        ['Account Number', account.get('account_number', '-'), 'Account Type', account.get('account_type', '-')],
        ['Full Name', account.get('full_name', '-'), 'Status', account.get('status', 'Active')],
        ['Email', account.get('email', '-'), 'Phone', account.get('phone', '-')],
        ['Date of Birth', str(account.get('date_of_birth', '-')), 'Member Since', str(account.get('created_at', '-'))[:10]],
        ['Address', account.get('address', '-'), '', ''],
    ]
    
    pt = Table(profile_data, colWidths=[4*cm, 6*cm, 4*cm, 4*cm])
    pt.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#e8eaf6')),
        ('BACKGROUND', (2, 0), (2, -1), colors.HexColor('#e8eaf6')),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#9fa8da')),
        ('PADDING', (0, 0), (-1, -1), 6),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ]))
    elements.append(pt)

    # Balance highlight
    elements.append(Spacer(1, 0.5*cm))
    bal = account.get('balance', 0)
    bal_table = Table([[f"Current Balance: ₹{float(bal):,.2f}"]], colWidths=[18*cm])
    bal_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#1a237e')),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.white),
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 16),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('PADDING', (0, 0), (-1, -1), 12),
        ('ROUNDEDCORNERS', [5]),
    ]))
    elements.append(bal_table)

    # Transactions
    elements.append(Paragraph("Transaction History (Last 20)", section_style))
    
    tx_data = [['#', 'Date', 'Type', 'Amount (₹)', 'Balance After (₹)', 'Description']]
    if transactions:
        for i, tx in enumerate(transactions[:20], 1):
            tx_data.append([
                str(i),
                str(tx.get('transaction_date', ''))[:16],
                tx.get('transaction_type', ''),
                f"{float(tx.get('amount', 0)):,.2f}",
                f"{float(tx.get('balance_after', 0)):,.2f}",
                str(tx.get('description', ''))[:30]
            ])
    else:
        tx_data.append(['-', 'No transactions found', '', '', '', ''])

    tt = Table(tx_data, colWidths=[0.8*cm, 3.5*cm, 2.5*cm, 3*cm, 3.5*cm, 4.7*cm])
    tt.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a237e')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#e8eaf6')]),
        ('GRID', (0, 0), (-1, -1), 0.3, colors.HexColor('#9fa8da')),
        ('PADDING', (0, 0), (-1, -1), 5),
        ('ALIGN', (3, 0), (4, -1), 'RIGHT'),
    ]))
    elements.append(tt)

    elements.append(Spacer(1, 1*cm))
    elements.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#9fa8da')))
    elements.append(Paragraph(f"Statement Generated: {datetime.now().strftime('%d %B %Y, %I:%M %p')} | Bank of Muthamizh | IFSC: BOMUT0000001",
                               ParagraphStyle('footer', parent=styles['Normal'], fontSize=8, textColor=colors.grey, alignment=TA_CENTER)))

    doc.build(elements)
    buf.seek(0)
    return buf

# ==========================================
# API Routes
# ==========================================

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({'status': 'healthy', 'service': 'Bank of Muthamizh', 'face_recognition': FACE_RECOGNITION_AVAILABLE})

@app.route('/api/register', methods=['POST'])
def register():
    try:
        data = request.json
        full_name = data.get('full_name')
        email = data.get('email')
        phone = data.get('phone')
        address = data.get('address', '')
        dob = data.get('dob')
        password = data.get('password')
        face_image = data.get('face_image')
        initial_deposit = float(data.get('initial_deposit', 0))
        account_type = data.get('account_type', 'Savings')

        if not all([full_name, email, phone, password]):
            return jsonify({'success': False, 'message': 'Required fields missing'}), 400

        # Check duplicate email
        if query("SELECT email FROM customers WHERE email=%s", (email,), fetch_one=True):
            return jsonify({'success': False, 'message': 'Email already registered'}), 400

        account_number = gen_account()
        
        # Handle face recognition
        face_path = None
        if face_image:
            if FACE_RECOGNITION_AVAILABLE:
                face_path = save_face(account_number, face_image)
                if not face_path:
                    return jsonify({'success': False, 'message': 'Face not detected. Try better lighting.'}), 400
            else:
                face_path = 'no_face_recognition'  # Fallback

        password_hash = hash_password(password)

        result = query("""
            INSERT INTO customers (account_number, full_name, email, phone, address, date_of_birth, 
            password_hash, face_encoding_path, balance, account_type)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """, (account_number, full_name, email, phone, address, dob, password_hash, face_path, initial_deposit, account_type))

        if result is None:
            return jsonify({'success': False, 'message': 'Registration failed'}), 500

        if initial_deposit > 0:
            query("""INSERT INTO transactions (account_number, transaction_type, amount, balance_before, balance_after, description)
                     VALUES (%s,'Deposit',%s,0,%s,'Initial Deposit')""", (account_number, initial_deposit, initial_deposit))

        logger.info(f"Account created: {account_number}")
        return jsonify({'success': True, 'message': 'Account created successfully!', 'account_number': account_number}), 201

    except Exception as e:
        logger.error(f"Register error: {e}")
        return jsonify({'success': False, 'message': 'Registration failed. Please try again.'}), 500

@app.route('/api/login', methods=['POST'])
def login():
    try:
        data = request.json
        account_number = data.get('account_number')
        password = data.get('password')
        face_image = data.get('face_image')

        if not all([account_number, password]):
            return jsonify({'success': False, 'message': 'Account number and password required'}), 400

        # Face verification if available and image provided
        if face_image and FACE_RECOGNITION_AVAILABLE:
            if not verify_face(account_number, face_image):
                return jsonify({'success': False, 'message': 'Face verification failed. Please try again.'}), 401

        pw_hash = hash_password(password)
        user = query("""SELECT account_number, full_name, email, phone, address, date_of_birth, 
                        balance, account_type, status, created_at 
                        FROM customers WHERE account_number=%s AND password_hash=%s""", 
                     (account_number, pw_hash), fetch_one=True)

        if not user:
            return jsonify({'success': False, 'message': 'Invalid account number or password'}), 401

        if user['status'] != 'Active':
            return jsonify({'success': False, 'message': f"Account is {user['status']}"}), 403

        user = serialize_dates(user)
        user['balance'] = float(user['balance'])

        session['account_number'] = account_number
        session['full_name'] = user['full_name']

        return jsonify({'success': True, 'message': 'Login successful', 'user': user}), 200

    except Exception as e:
        logger.error(f"Login error: {e}")
        return jsonify({'success': False, 'message': 'Login failed. Try again.'}), 500

@app.route('/api/account', methods=['GET'])
def get_account():
    if 'account_number' not in session:
        return jsonify({'success': False, 'message': 'Not authenticated'}), 401
    
    acc = query("""SELECT account_number, full_name, email, phone, address, date_of_birth, 
                   balance, account_type, status, created_at 
                   FROM customers WHERE account_number=%s""", (session['account_number'],), fetch_one=True)
    
    if acc:
        acc = serialize_dates(acc)
        acc['balance'] = float(acc['balance'])
        return jsonify({'success': True, 'account': acc}), 200
    return jsonify({'success': False, 'message': 'Account not found'}), 404

@app.route('/api/transactions', methods=['GET'])
def get_transactions():
    if 'account_number' not in session:
        return jsonify({'success': False, 'message': 'Not authenticated'}), 401
    
    limit = request.args.get('limit', 20, type=int)
    txns = query("""SELECT transaction_id, transaction_type, amount, balance_before, balance_after, 
                    description, transaction_date FROM transactions 
                    WHERE account_number=%s ORDER BY transaction_date DESC LIMIT %s""",
                 (session['account_number'], limit), fetch=True)
    
    if txns:
        for t in txns:
            t = serialize_dates(t)
            t['amount'] = float(t['amount'])
            t['balance_before'] = float(t['balance_before'])
            t['balance_after'] = float(t['balance_after'])
    
    return jsonify({'success': True, 'transactions': txns or []}), 200

@app.route('/api/deposit', methods=['POST'])
def deposit():
    if 'account_number' not in session:
        return jsonify({'success': False, 'message': 'Not authenticated'}), 401
    try:
        data = request.json
        amount = float(data.get('amount', 0))
        description = data.get('description', 'Cash Deposit')
        account_number = session['account_number']

        if amount <= 0:
            return jsonify({'success': False, 'message': 'Invalid amount'}), 400

        face_image = data.get('face_image')
        if face_image and FACE_RECOGNITION_AVAILABLE:
            if not verify_face(account_number, face_image):
                return jsonify({'success': False, 'message': 'Face verification failed'}), 401

        conn = get_db()
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT balance, full_name FROM customers WHERE account_number=%s", (account_number,))
        result = cur.fetchone()
        current_balance = float(result['balance'])
        new_balance = current_balance + amount

        cur.execute("UPDATE customers SET balance=%s WHERE account_number=%s", (new_balance, account_number))
        cur.execute("""INSERT INTO transactions (account_number, transaction_type, amount, balance_before, balance_after, description)
                       VALUES (%s,'Deposit',%s,%s,%s,%s)""", (account_number, amount, current_balance, new_balance, description))
        
        tx_id = cur.lastrowid
        conn.commit()
        cur.close()
        conn.close()

        return jsonify({
            'success': True,
            'message': 'Deposit successful',
            'new_balance': new_balance,
            'transaction_id': tx_id,
            'amount': amount,
            'account_number': account_number,
            'full_name': result['full_name'],
            'description': description,
            'transaction_date': datetime.now().isoformat()
        }), 200

    except Exception as e:
        logger.error(f"Deposit error: {e}")
        return jsonify({'success': False, 'message': 'Deposit failed'}), 500

@app.route('/api/withdraw', methods=['POST'])
def withdraw():
    if 'account_number' not in session:
        return jsonify({'success': False, 'message': 'Not authenticated'}), 401
    try:
        data = request.json
        amount = float(data.get('amount', 0))
        description = data.get('description', 'Cash Withdrawal')
        account_number = session['account_number']

        if amount <= 0:
            return jsonify({'success': False, 'message': 'Invalid amount'}), 400

        face_image = data.get('face_image')
        if face_image and FACE_RECOGNITION_AVAILABLE:
            if not verify_face(account_number, face_image):
                return jsonify({'success': False, 'message': 'Face verification failed'}), 401

        conn = get_db()
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT balance, full_name FROM customers WHERE account_number=%s", (account_number,))
        result = cur.fetchone()
        current_balance = float(result['balance'])

        if current_balance < amount:
            cur.close()
            conn.close()
            return jsonify({'success': False, 'message': f'Insufficient balance. Available: ₹{current_balance:,.2f}'}), 400

        new_balance = current_balance - amount
        cur.execute("UPDATE customers SET balance=%s WHERE account_number=%s", (new_balance, account_number))
        cur.execute("""INSERT INTO transactions (account_number, transaction_type, amount, balance_before, balance_after, description)
                       VALUES (%s,'Withdrawal',%s,%s,%s,%s)""", (account_number, amount, current_balance, new_balance, description))
        
        tx_id = cur.lastrowid
        conn.commit()
        cur.close()
        conn.close()

        return jsonify({
            'success': True,
            'message': 'Withdrawal successful',
            'new_balance': new_balance,
            'transaction_id': tx_id,
            'amount': amount,
            'account_number': account_number,
            'full_name': result['full_name'],
            'description': description,
            'transaction_date': datetime.now().isoformat()
        }), 200

    except Exception as e:
        logger.error(f"Withdrawal error: {e}")
        return jsonify({'success': False, 'message': 'Withdrawal failed'}), 500

# ==========================================
# Loan Routes
# ==========================================

@app.route('/api/loans', methods=['GET'])
def get_loans():
    if 'account_number' not in session:
        return jsonify({'success': False, 'message': 'Not authenticated'}), 401

    loans = query("""SELECT * FROM loan_applications WHERE account_number=%s ORDER BY applied_at DESC""",
                  (session['account_number'],), fetch=True)
    
    if loans:
        for loan in loans:
            loan = serialize_dates(loan)
            loan['loan_amount'] = float(loan['loan_amount'])
            loan['monthly_income'] = float(loan['monthly_income'])
            loan['emi_amount'] = float(loan['emi_amount']) if loan['emi_amount'] else 0
    
    return jsonify({'success': True, 'loans': loans or []}), 200

@app.route('/api/loans/apply', methods=['POST'])
def apply_loan():
    if 'account_number' not in session:
        return jsonify({'success': False, 'message': 'Not authenticated'}), 401
    try:
        data = request.form if request.form else request.json
        account_number = session['account_number']
        
        loan_type = data.get('loan_type')
        loan_amount = float(data.get('loan_amount', 0))
        tenure_months = int(data.get('tenure_months', 12))
        monthly_income = float(data.get('monthly_income', 0))
        pancard = data.get('pancard_number', '').upper().strip()
        aadhar = data.get('aadhar_number', '').replace(' ', '').strip()
        employment_type = data.get('employment_type', '')
        purpose = data.get('purpose', '')

        if not all([loan_type, loan_amount, monthly_income, pancard, aadhar]):
            return jsonify({'success': False, 'message': 'All fields required'}), 400

        # Validate PAN: ABCDE1234F format
        import re
        if not re.match(r'^[A-Z]{5}[0-9]{4}[A-Z]$', pancard):
            return jsonify({'success': False, 'message': 'Invalid PAN card number format (e.g., ABCDE1234F)'}), 400

        if not re.match(r'^\d{12}$', aadhar):
            return jsonify({'success': False, 'message': 'Aadhar must be 12 digits'}), 400

        # Interest rates by loan type
        rates = {
            'Home Loan': 8.50, 'Personal Loan': 12.00, 'Education Loan': 9.50,
            'Vehicle Loan': 10.50, 'Business Loan': 14.00, 'Gold Loan': 7.50
        }
        rate = rates.get(loan_type, 10.50)
        emi = calc_emi(loan_amount, rate, tenure_months)

        # Handle file uploads
        pancard_path = None
        aadhar_path = None
        if request.files:
            if 'pancard_image' in request.files:
                f = request.files['pancard_image']
                pancard_path = os.path.join(UPLOAD_DIR, 'kyc', f"{account_number}_pan_{f.filename}")
                f.save(pancard_path)
            if 'aadhar_image' in request.files:
                f = request.files['aadhar_image']
                aadhar_path = os.path.join(UPLOAD_DIR, 'kyc', f"{account_number}_aadhar_{f.filename}")
                f.save(aadhar_path)

        result = query("""INSERT INTO loan_applications 
                         (account_number, loan_type, loan_amount, tenure_months, monthly_income, 
                          pancard_number, aadhar_number, pancard_image_path, aadhar_image_path,
                          employment_type, purpose, interest_rate, emi_amount)
                         VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                      (account_number, loan_type, loan_amount, tenure_months, monthly_income,
                       pancard, aadhar, pancard_path, aadhar_path, employment_type, purpose, rate, emi))

        return jsonify({
            'success': True,
            'message': f'{loan_type} application submitted successfully! EMI: ₹{emi:,.2f}/month',
            'loan_id': result,
            'emi_amount': emi,
            'interest_rate': rate
        }), 201

    except Exception as e:
        logger.error(f"Loan apply error: {e}")
        return jsonify({'success': False, 'message': 'Loan application failed'}), 500

@app.route('/api/loans/calculate', methods=['POST'])
def calc_loan():
    data = request.json
    principal = float(data.get('amount', 0))
    rate = float(data.get('rate', 10.50))
    months = int(data.get('months', 12))
    emi = calc_emi(principal, rate, months)
    total = emi * months
    interest = total - principal
    return jsonify({'emi': emi, 'total': round(total, 2), 'interest': round(interest, 2), 'rate': rate})

# ==========================================
# PDF Download Routes
# ==========================================

@app.route('/api/receipt/download', methods=['POST'])
def download_receipt():
    if 'account_number' not in session:
        return jsonify({'success': False, 'message': 'Not authenticated'}), 401
    try:
        data = request.json
        receipt_type = data.get('type', 'Transaction')
        account_number = session['account_number']
        
        acc = query("SELECT full_name FROM customers WHERE account_number=%s", (account_number,), fetch_one=True)

        receipt_data = {
            'Receipt No': f"RCP{data.get('transaction_id', '000')}",
            'Account Number': account_number,
            'Account Holder': acc['full_name'] if acc else '-',
            'Transaction Type': receipt_type,
            'Amount': f"₹{float(data.get('amount', 0)):,.2f}",
            'Balance After Transaction': f"₹{float(data.get('new_balance', 0)):,.2f}",
            'Description': data.get('description', '-'),
            'Date & Time': datetime.now().strftime('%d %B %Y, %I:%M:%S %p'),
            'Status': 'SUCCESS',
            'Bank': 'Bank of Muthamizh',
            'IFSC Code': 'BOMUT0000001',
            'Branch': 'Main Branch, Madurai'
        }

        pdf_buf = generate_receipt_pdf(receipt_data, receipt_type)
        filename = f"BOM_{receipt_type}_{data.get('transaction_id', 'receipt')}_{datetime.now().strftime('%Y%m%d%H%M%S')}.pdf"
        
        return send_file(pdf_buf, as_attachment=True, download_name=filename, mimetype='application/pdf')

    except Exception as e:
        logger.error(f"Receipt PDF error: {e}")
        return jsonify({'success': False, 'message': 'PDF generation failed'}), 500

@app.route('/api/account/download-pdf', methods=['GET'])
def download_account_pdf():
    if 'account_number' not in session:
        return jsonify({'success': False, 'message': 'Not authenticated'}), 401
    try:
        account_number = session['account_number']
        acc = query("""SELECT * FROM customers WHERE account_number=%s""", (account_number,), fetch_one=True)
        txns = query("""SELECT * FROM transactions WHERE account_number=%s ORDER BY transaction_date DESC LIMIT 20""",
                    (account_number,), fetch=True)

        if acc:
            acc = serialize_dates(acc)
        if txns:
            for t in txns:
                t = serialize_dates(t)

        pdf_buf = generate_account_pdf(acc or {}, txns or [])
        filename = f"BOM_Account_{account_number}_{datetime.now().strftime('%Y%m%d')}.pdf"
        return send_file(pdf_buf, as_attachment=True, download_name=filename, mimetype='application/pdf')

    except Exception as e:
        logger.error(f"Account PDF error: {e}")
        return jsonify({'success': False, 'message': 'PDF generation failed'}), 500

@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True, 'message': 'Logged out successfully'}), 200

@app.errorhandler(404)
def not_found(e):
    return jsonify({'success': False, 'message': 'Endpoint not found'}), 404

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    logger.info(f"Starting Bank of Muthamizh on port {port}")
    logger.info(f"Face Recognition: {'Enabled' if FACE_RECOGNITION_AVAILABLE else 'Disabled (password-only mode)'}")
    app.run(host='0.0.0.0', port=port, debug=True)
